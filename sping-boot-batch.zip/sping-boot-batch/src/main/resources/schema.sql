create table stock(
	stock_id int,
	symbol varchar2(10),
	price decimal(10,2)
);

insert into stock values(1,'SYS',10);
insert into stock values(2,'GOOG',10);
insert into stock values(3,'FB',10);

DROP TABLE people IF EXISTS;

CREATE TABLE people  (
    person_id BIGINT IDENTITY NOT NULL PRIMARY KEY,
    first_name VARCHAR(20),
    last_name VARCHAR(20)
);
