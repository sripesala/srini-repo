package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.module.afterburner.deser.SettableIntMethodProperty;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.netflix.ribbon.proxy.annotation.Hystrix;

@EnableCircuitBreaker
@SpringBootApplication
@RestController
@EnableEurekaClient
public class SampleEurekaTemplateApplication {

	@Autowired
	RestTemplate restTemplate;
	public static void main(String[] args) {
		SpringApplication.run(SampleEurekaTemplateApplication.class, args);
	}
	
	@HystrixCommand(fallbackMethod="fallback")
	@HystrixProperty(name="hystrix.command.default.execution.isolation.thread.timeoutIn‌Milliseconds",value="1000")
	@GetMapping("tempGet")
	public String templateGreeting() {
		return restTemplate.getForObject("http://SRINI-CLIENT/greet/srinu", String.class);
	}
	
	public String fallback() {
		return "fallback-greeting";
	}
	
	
	
}

@Configuration
class config{
	
	

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}


	
}

